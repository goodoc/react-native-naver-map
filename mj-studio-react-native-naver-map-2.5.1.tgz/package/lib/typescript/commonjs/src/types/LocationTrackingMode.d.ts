/**
 * 사용자의 위치를 추적하는 모드입니다.
 *
 * - None: 위치를 추적하지 않습니다.
 * - NoFollow: 위치 추적이 활성화되고, 현위치 오버레이가 사용자의 위치를 따라 움직입니다. 그러나 지도는 움직이지 않습니다.
 * - Follow: 위치 추적이 활성화되고, 현위치 오버레이와 카메라의 좌표가 사용자의 위치를 따라 움직입니다.
 * API나 제스처를 사용해 임의로 카메라를 움직일 경우 모드가 NoFollow로 바뀝니다.
 * - Face:위치 추적이 활성화되고, 현위치 오버레이, 카메라의 좌표, 베어링이 사용자의 위치 및 방향을 따라 움직입니다.
 * API나 제스처를 사용해 임의로 카메라를 움직일 경우 모드가 NoFollow로 바뀝니다.
 */
export type LocationTrackingMode = 'None' | 'NoFollow' | 'Follow' | 'Face';
//# sourceMappingURL=LocationTrackingMode.d.ts.map