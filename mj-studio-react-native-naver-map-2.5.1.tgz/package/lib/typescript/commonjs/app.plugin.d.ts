declare const _exports: any;
export = _exports;
//# sourceMappingURL=app.plugin.d.ts.map